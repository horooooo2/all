const s="/assets/icon_deposit-D0ECJ0rD.svg";export{s as i};
