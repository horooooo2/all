const s="/assets/no_data-BNbUn3-f.svg";export{s as n};
