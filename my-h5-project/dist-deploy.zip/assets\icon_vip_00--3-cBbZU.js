const s="/assets/icon_vip_00-CUC031gV.svg";export{s as i};
