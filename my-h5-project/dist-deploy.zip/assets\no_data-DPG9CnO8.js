const s="/assets/no_data-BdMwuzeO.png";export{s as n};
