const s="/assets/logo-obCKIW9-.svg";export{s as _};
