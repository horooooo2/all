const s="/assets/touxiang2-OCQSV1WT.png";export{s as d};
